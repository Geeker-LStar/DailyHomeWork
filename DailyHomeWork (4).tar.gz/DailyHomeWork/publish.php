<!--作业发布后台（发布）-->

<?php
    session_start();
?>

<?php
    // 检查是否登录，未登录则要求登录
    if (!isset($_SESSION['user']))
        header("Location: login.php");
?>

<!DOCTYPE html>
<html>
    <head>
        <title>发布作业 - 作业发布后台</title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="hw-css/button_style1.css">
    </head>
    
    <body>
        <h1>发布作业</h1>
        <?php
            // 获取年月（数据表名）日（日期）
            $table_name = date("Y_m");
            $date = date("d");
        ?>
        <form action="execute.php" method="POST">
            <input type="hidden" name="type" value="publish">
            <label for="tablen">数据表名（默认为 YYYY_MM）：</label><br>
            <textarea id="tablen" name="tablen" class="form-control"><?php echo $table_name;?></textarea><br>
            <label for="date">日期：</label><br>
            <textarea id="date" name="date" class="form-control"><?php echo $date;?></textarea><br>
            <label for="yw">语文：</label><br>
            <textarea id="yw" name="yw" style="height: 180px; width: 400px;" class="form-control"></textarea><br>
            <label for="sx">数学：</label><br>
            <textarea id="sx" name="sx" style="height: 180px; width: 400px;" class="form-control"></textarea><br>
            <label for="yy">英语：</label><br>
            <textarea id="yy" name="yy" style="height: 180px; width: 400px;" class="form-control"></textarea><br>
            <label for="wl">物理：</label><br>
            <textarea id="wl" name="wl" style="height: 180px; width: 400px;" class="form-control"></textarea><br>
            <label for="hx">化学：</label><br>
            <textarea id="hx" name="hx" style="height: 180px; width: 400px;" class="form-control"></textarea><br>
            <label for="sw">生物：</label><br>
            <textarea id="sw" name="sw" style="height: 180px; width: 400px;" class="form-control"></textarea><br>
            <label for="dl">地理：</label><br>
            <textarea id="dl" name="dl" style="height: 180px; width: 400px;" class="form-control"></textarea><br>
            <label for="ls">历史：</label><br>
            <textarea id="ls" name="ls" style="height: 180px; width: 400px;" class="form-control"></textarea><br>
            <label for="df">道法：</label><br>
            <textarea id="df" name="df" style="height: 180px; width: 400px;" class="form-control"></textarea><br>
            <label for="qt">其他：</label><br>
            <textarea id="qt" name="qt" style="height: 180px; width: 400px;" class="form-control"></textarea><br>
            <input type="submit" name="publish" value="确认发布" class="btn" style="-webkit-appearance: none;">
        </form>
    </body>
</html>
