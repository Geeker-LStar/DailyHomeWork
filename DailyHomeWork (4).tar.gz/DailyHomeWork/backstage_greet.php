<!--作业发布后台（默认页面）-->

<?php
    session_start();
?>
<?php
    // 检查是否登录，未登录则要求登录
    if (!isset($_SESSION['user']))
        header("Location: login.php");
?>

<?php
    require_once("./config.php");
?>


<!DOCTYPE html>
<html>
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>欢迎页面 - 作业发布后台</title>
        <link rel="stylesheet" href="hw-css/footer.css">
    </head>
    
    <body>
        
        <div style="background-color: skyblue; padding: 10%; margin: 12%;">
            <center><h2>欢迎来到作业发布网站后台！</h2>
            <p>你可在左侧操作栏选择下一步操作。</p></center>
        </div>
        
        <div class="footer" style="position: fixed; bottom: 5px; width: 100%;">
            <h2><?php echo $footer;?></h2>
            <p><?php echo $love_thanks;?></p>
        </div>
    </body>
</html>