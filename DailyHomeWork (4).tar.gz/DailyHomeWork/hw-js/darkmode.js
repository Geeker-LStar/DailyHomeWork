// 暗黑模式
function dark_mode() {
    var old_style = document.getElementById("html").style.filter;
    // 暗黑——亮白
    if (old_style == "invert(1) hue-rotate(180deg)") {
        document.getElementById("html").style.filter = "invert(0) hue-rotate(0deg)";
        var imgs = document.getElementsByTagName("img");
        for (var i = 0; i < imgs.length; i++)
        {
            imgs[i].style.filter = "invert(0) hue-rotate(0deg)";
            imgs[i].style.boxShadow = "5px 5px 10px rgba(20, 20, 20, 0.2)";
        }
        document.getElementById("switch").src = "./hw-imgs/light_pic.png";
    }
    // 亮白——暗黑
    else {
        document.getElementById("html").style.filter = "invert(1) hue-rotate(180deg)";
        var imgs = document.getElementsByTagName("img");
        for (var j = 0; j < imgs.length; j++)
        {
            imgs[j].style.filter = "invert(0.85) hue-rotate(180deg)"; 
            imgs[j].style.boxShadow = "5px 5px 10px rgba(240, 240, 240, 0.5)";
        }
        document.getElementById("switch").src = "./hw-imgs/dark_pic.png";
    }
}