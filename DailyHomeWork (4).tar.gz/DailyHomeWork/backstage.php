<!--作业发布后台（集成）-->

<?php
    session_start();
?>

<?php
    if (!isset($_SESSION['user']))
        header("Location: login.php");
?>

<?php
    $magic_num = rand(100000, 999999);    // 随机数，保证每次显示的图片都是最新的（无论是否开启缓存）
?>

<?php
    require_once("functions.php");
?>

<?php
    if (isset($_GET["logout"]))
        log_out();
?>
<!DOCTYPE html>
<html id="html">
    <head>
        <title>作业发布后台</title>
        <link rel="stylesheet" href="hw-css/full.css">
        <link rel="stylesheet" href="hw-css/backstage.css">
        <link rel="stylesheet" href="hw-css/button_style1.css">
        <link rel="stylesheet" href="hw-includes/node_modules/bootstrap/dist/css/bootstrap.min.css">
        <script src="hw-js/darkmode.js"></script>
        <script src="hw-js/darkmode-system.js"></script>
    </head>
    
    <body>
        <script>
            function iframe(php_link)
            {   
                var link = php_link + ".php"
                ifr = document.getElementById("ifr");
                ifr.src = link;
            }
        </script>
        
        <div class="left" style="margin-left: 2px; border: 1px solid #333; border-radius: 10px; box-shadow: 10px 10px 10px gray;">
            <center><img src="hw-imgs/logo.jpg?random=<?php echo $magic_num;?>" style="height: 200px; width: 200px; margin-top: 32px; border-radius: 10px;" ></center>
            <ul class="nav nav-pills flex-column mb-auto">
                <hr>
                <li class="nav-item">
                    <a onclick="iframe('backstage_greet');" class="nav-link link-dark" aria-current="page" id="index">
                    <svg class="bi me-2" width="16" height="16"></svg>
                    欢迎页面
                    </a>
                </li>
                <hr>
                <li class="nav-item">
                    <a onclick="iframe('index');" class="nav-link link-dark" aria-current="page" id="index">
                    <svg class="bi me-2" width="16" height="16"></svg>
                    首页
                    </a>
                </li>
                <hr>
                <li>
                    <a onclick="iframe('publish');" class="nav-link link-dark">
                    <svg class="bi me-2" width="16" height="16"></svg>
                    发布作业
                    </a>
                </li>
                <hr>
                <li>
                    <a onclick="iframe('modify');" class="nav-link link-dark">
                    <svg class="bi me-2" width="16" height="16"></svg>
                    修改 / 查找作业
                    </a>
                </li>
                <hr>
                <li class="nav-item">
                    <a onclick="iframe('email_service');" class="nav-link link-dark" aria-current="page">
                    <svg class="bi me-2" width="16" height="16"></svg>
                    配置邮件服务
                    </a>
                </li>
                <hr>
                <li>
                    <a onclick="iframe('mng_sscrb');" class="nav-link link-dark">
                    <svg class="bi me-2" width="16" height="16"></svg>
                    管理订阅者
                    </a>
                </li>
                <hr>
                <li>
                    <a onclick="iframe('set_imgs');" class="nav-link link-dark">
                    <svg class="bi me-2" width="16" height="16"></svg>
                    设置特色图片
                    </a>
                </li>
                <hr>
                <li class="nav-item">
                    <a onclick="iframe('mdf_cfg');" class="nav-link link-dark" aria-current="page">
                    <svg class="bi me-2" width="16" height="16"></svg>
                    修改配置
                    </a>
                </li>
                <hr>
            </ul>
            
            <form action="backstage.php" method="get"><input type="submit" name="logout" value="退出登录" class="btn btn-danger" style="-webkit-appearance: none; float: right;"></form>
        </div>
            
        <div class="right">
            <iframe height="100%" width="100%" src="backstage_greet.php" id="ifr"></iframe>
        </div>
    </body>
</html>