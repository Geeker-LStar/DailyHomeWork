<!--作业发布网站（安装）-->

<!DOCTYPE html>
<?php
    require_once("config.php");
    require_once("functions.php");
?>

<title>安装 —— 每日作业发布</title>
<h1>安装 DHW 每日作业至您的网站</h1>
<h3>——极简的三步安装程序</h3>

<!--第一步：配置数据库-->
<?php
    if (!isset($_POST["step"])) {
?>

<h3>第一步：配置数据库</h3>
<form action="setup.php" method="post">
    数据库主机：<input type="text" name="server" value="localhost"><br><br>
    数据库用户名：<input type="text" name="username"><br><br>
    数据库密码：<input type="password" name="password"><br><br>
    数据库名称：<input type="text" name="dbname"><br><br>
    <input type="hidden" name="step" value="2">
    <input type="submit" name="connect" value="确认">
</form><hr>
<?php
    }
?>

<?php
    // 获取数据库配置信息
    if (isset($_POST["connect"]))
    {
        // 获取数据
        $servername = $_POST["server"];
        $username = $_POST["username"];
        $password = $_POST["password"];
        $dbname = $_POST["dbname"];
        $begin_year = date("Y");
        $begin_time = date("Y-m-d H:i:s");
        
        // 修改配置文件
        modify_configs("servername = ", $servername);
        modify_configs("username = ", $username);
        modify_configs("password = ", $password);
        modify_configs("dbname = ", $dbname);
        modify_configs("begin_year = ", $begin_year);
        modify_configs("begin_time = ", $begin_time);
    }
?>

<?php
    // 连接数据库
    date_default_timezone_set("PRC");    // 时区
    $conn = new mysqli($servername, $username, $password, $dbname);
    if ($conn->connect_error)
        die("连接失败：" . $conn->connect_error);
?>

<?php
    // 创建存放配置信息的数据表
    $sql = "CREATE TABLE `{$dbname}` . `Configs` ( 
            `id` INT(20) NOT NULL AUTO_INCREMENT COMMENT '自增主键' , 
            `cfgkey` VARCHAR(256) NOT NULL COMMENT '配置项目（键）' , 
            `cfgvalue` VARCHAR(1320) NOT NULL COMMENT '配置项目（值）' , 
            `description` VARCHAR(725) NOT NULL COMMENT '配置项目（描述）' , 
            PRIMARY key (`id`)) ENGINE = InnoDB COMMENT = '网站配置信息';";
    $conn->query($sql);
    // 创建存放用户（管理员）信息的数据表
    $sql = "CREATE TABLE `{$dbname}`. `Users` ( 
            `id` INT(20) NOT NULL AUTO_INCREMENT COMMENT '自增主键' , 
            `username` VARCHAR(20) NOT NULL COMMENT '管理员用户名' , 
            `password` VARCHAR(24) NOT NULL COMMENT '管理员密码' , 
            `extra` VARCHAR(725) NOT NULL COMMENT '管理员额外信息' , 
            PRIMARY key (`id`)) ENGINE = InnoDB COMMENT = '网站管理员的信息';";
    $conn->query($sql);
    // 创建存放订阅者信息的数据表
    $sql = "CREATE TABLE `{$dbname}`. `Subscribers` ( 
            `id` INT(20) NOT NULL AUTO_INCREMENT COMMENT '自增主键' , 
            `name` VARCHAR(20) NOT NULL COMMENT '订阅者用户名' , 
            `email` VARCHAR(256) NOT NULL COMMENT '订阅者邮箱' , 
            `is_receive` INT(1) NOT NULL COMMENT '订阅者是否接收邮件（默认接收）' , 
            `time` VARCHAR(30) NOT NULL COMMENT '订阅时间' , 
            PRIMARY key (`id`)) ENGINE = InnoDB COMMENT = '网站管理员的信息';";
    $conn->query($sql);
?>

<!--第二步：设置管理员账户-->
<?php
    if (isset($_POST["step"]) && $_POST["step"] == 2) {
?>
<h3>第二步：设置管理员账户</h3>
<form action="setup.php" method="post">
    <p>请记住您的用户名和密码。</p>
    管理员用户名：<input type="text" name="admin_usern"><br><br>
    管理员密码：<input type="password" name="admin_pwd"><br><br>
    <input type="hidden" name="step" value="3">
    <input type="submit" name="admin" value="确认">
</form><hr>
<?php
    }
?>

<?php
if (isset($_POST["admin"]))
{
    $a_u = $_POST["admin_usern"];
    $a_p = $_POST["admin_pwd"];
    $sql = "INSERT INTO Users (username, password) VALUES ('{$a_u}', '{$a_p}')";
    $conn->query($sql);
    echo mysqli_error($conn);
}
?>

<!--第三步：设置网站标题等重要内容-->
<?php
    if (isset($_POST["step"]) && $_POST["step"] == 3) {
?>
<h3>第三步：设置网站标题等重要内容</h3>
<form action="setup.php" method="post" enctype="multipart/form-data">
    浏览器标签页标题：<input type="text" name="site_title" value=<?php echo $site_title;?>><br><br>
    首页主标题：<input type="text" name="header_main_title" value=<?php echo $header_main_title;?>><br><br>
    首页副标题：<input type="text" name="header_secondary_title" value=<?php echo $header_secondary_title;?>><br><br>
    班级全称：<input type="text" name="class_full_name" value=<?php echo $class_full_name;?>><br><br>
    班级简称：<input type="text" name="class_short_name" value=<?php echo $class_short_name;?>><br><br>
    <input type="hidden" name="step" value="finished">
    <input type="submit" name="basic_info" value="确认">
</form><hr>
<?php
    }
?>

<?php
    if (isset($_POST["basic_info"]))
    {
        // 获取数据
        $site_title = $_POST["site_title"];
        $header_main_title = $_POST["header_main_title"];
        $header_secondary_title = $_POST["header_secondary_title"];
        $class_short_name = $_POST["class_short_name"];
        $class_full_name = $_POST["class_full_name"];
        
        // 修改配置文件
        modify_configs("site_title = ", $site_title);
        modify_configs("header_main_title = ", $header_main_title);
        modify_configs("header_secondary_title = ", $header_main_title);
        modify_configs("class_short_name = ", $class_short_name);
        modify_configs("class_full_name = ", $class_full_name);
    }
?>

<!--安装成功-->
<?php
    if (isset($_POST["step"]) && $_POST["step"] == "finished") {
?>
<p style="color: red">安装成功！</p>
<a href='backstage.php'>去后台</a>
<?php
    }
?>

<?php
    // 添加配置信息
    // 数据库基本配置
    // $sql = "INSERT INTO Configs (cfgkey, cfgvalue, description) VALUES ('servername', '{$servername}', '数据库主机')";
    // $conn->query($sql);
    // $sql = "INSERT INTO Configs (cfgkey, cfgvalue, description) VALUES ('username', '{$username}', '数据库用户名')";
    // $conn->query($sql);
    // $sql = "INSERT INTO Configs (cfgkey, cfgvalue, description) VALUES ('password', '{$password}', '数据库密码')";
    // $conn->query($sql);
    // $sql = "INSERT INTO Configs (cfgkey, cfgvalue, description) VALUES ('dbname', '{$dbname}', '数据库名称')";
    // $conn->query($sql);
    // // 时间基本配置
    // $sql = "INSERT INTO Configs (cfgkey, cfgvalue, description) VALUES ('begin_year', '{$begin_year}', '网站开始使用的年份')";
    // $conn->query($sql);
    // $sql = "INSERT INTO Configs (cfgkey, cfgvalue, description) VALUES ('begin_time', '{$begin_time}', '网站开始使用的具体时间')";
    // $conn->query($sql);
    // echo(mysqli_error($conn));
    // 邮件基本配置
    // 网站前端显示基本配置
    // 班级信息
?>
