<!--作业发布后台（修改）-->

<?php
    session_start();
?>
<?php
    // 检查是否登录，未登录则要求登录
    if (!isset($_SESSION['user']))
        header("Location: login.php");
?>

<!DOCTYPE html>
<html>
    <head>
        <title>修改 / 查找作业 - 作业发布后台</title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
    </head>
    
    <body>
        <script>
            function showHw(time)
            {   
                var xmlhttp;
                if (time == "") {
                    document.getElementById(hw).innerHTML = "";
                    return;
                }
                if (window.XMLHttpRequest) {
                    xmlhttp = new XMLHttpRequest();
                }
                else {
                    xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
                }
                xmlhttp.onreadystatechange = function() {
                    if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
                        document.getElementById("hw").innerHTML = xmlhttp.responseText;
                    }
                }
                xmlhttp.open("GET", "search.php?time="+time, true);
                xmlhttp.send();
            }
        </script>
        
        <h1>修改 / 查找作业</h1>
        <strong>请选择要修改 / 查找的作业的日期</strong>
        <p>如要查找周末作业，请选择周五的时间。</p>
    
        <form action="">
            <input type="date" onchange="showHw(this.value)">
        </form>
        <div id="hw"></div>
    </body>
</html>