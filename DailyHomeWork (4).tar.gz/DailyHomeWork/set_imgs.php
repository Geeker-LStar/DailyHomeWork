<!--作业发布后台（设置特色图片）-->

<?php
    require_once("config.php");    // 配置文件
?>

<?php
    session_start();
?>
<?php
    // 检查是否登录，未登录则要求登录
    if (!isset($_SESSION['user']))
        header("Location: login.php");
?>

<?php
    $magic_num = rand(100000, 999999);    // 随机数，保证每次显示的图片都是最新的（无论是否开启缓存）
?>

<!DOCTYPE html>
<html>
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>设置特色图片 —— 作业发布后台</title>
        <link rel="stylesheet" href="hw-css/button_style1.css">
    </head>
    
    <body>
        <h1>设置特色图片</h1>
        <strong>支持 png/jpg/jpeg/gif 格式</strong>
        <p>注 1：更新图片后需要刷新原网页才能看到效果。</p>
        <p>注 2：由于浏览器缓存等因素，首页显示的图片可能不会实时更新（班徽除外）。</p>        
        <hr>
        <h3>设置班徽（大小需小于 200kb）</h3>
        <form action="set_imgs.php" method="post" enctype="multipart/form-data">
            <input type="file" name="logo"><br><br>
            <input type="submit" name="setlogo" class="btn" style="-webkit-appearance: none;">
        </form>
        <hr>
        <h3>设置查找作业页面的特色图片（首页展示）</h3>
        <form action="set_imgs.php" method="post" enctype="multipart/form-data">
            <input type="file" name="search"><br><br>
            <input type="submit" name="setsearch" class="btn" style="-webkit-appearance: none;">
        </form>
        <hr>
        <h3>设置某年某月的特色图片（首页展示）</h3>
        <form action="set_imgs.php" method="post"  enctype="multipart/form-data">
            <select name="year">
            <?php
                for ($i = 2020; $i < 2100; $i++)
                    echo "<option value=" . $i . ">" . $i . "</option>";
            ?>
            </select>
            <select name="month">
            <?php
                for ($i = 1; $i < 13; $i++)
                {
                    if ($i < 10)
                        echo "<option value=0" . $i . ">" . $i . "</option>";
                    else
                        echo "<option value=" . $i . ">" . $i . "</option>";
                }
            ?>
            </select><br><br>
            <input type="file" name="feature"><br><br>
            <input type="submit" name="setfeature" class="btn" style="-webkit-appearance: none;">
        </form>
        <hr><br>
    </body>
</html>

<?php
    if (isset($_POST["setsearch"]))
    {
        if ((($_FILES["search"]["type"] == "image/gif")
        || ($_FILES["search"]["type"] == "image/jpeg")
        || ($_FILES["search"]["type"] == "image/jpg")
        || ($_FILES["search"]["type"] == "image/png"))) {
            if ($_FILES["search"]["error"] > 0)
                echo "<p style='color: red;'>错误：: " . $_FILES["search"]["error"] . "<p style='color: red;'><br>";
            else
            {   
                $target_url = "hw-imgs/search.jpg";
                move_uploaded_file($_FILES["search"]["tmp_name"], $target_url);
                echo "<p style='color: red;'>设置查找作业页面的特色图片成功。</p><br><br>";
                echo "<img src='$target_url?random=$magic_num' style='height: 170px; width: 250px;'>";
            }
        }
        else
            echo "文件类型错误。";
    }
    
    if (isset($_POST["setlogo"]))
    {
        if ((($_FILES["logo"]["type"] == "image/gif")
        || ($_FILES["logo"]["type"] == "image/jpeg")
        || ($_FILES["logo"]["type"] == "image/jpg")
        || ($_FILES["logo"]["type"] == "image/png"))) {
            if ($_FILES["logo"]["error"] > 0)
                echo "<p style='color: red;'>错误：: " . $_FILES["logo"]["error"] . "<p style='color: red;'><br>";
            elseif ($_FILES["logo"]["size"] > 204800)
                echo "<p style='color: red;'>图片过大。<p style='color: red;'>";
            else
            {   
                $target_url = "hw-imgs/logo.jpg";
                move_uploaded_file($_FILES["logo"]["tmp_name"], $target_url);
                echo "<p style='color: red;'>设置班徽成功。</p><br><br>";
                echo "<img src='$target_url?random=$magic_num' style='height: 170px; width: 170px;'>";
            }
        }
        else
            echo "文件类型错误。";
        
    }
    
    if (isset($_POST["setfeature"]))
    {
        if ((($_FILES["feature"]["type"] == "image/gif")
        || ($_FILES["feature"]["type"] == "image/jpeg")
        || ($_FILES["feature"]["type"] == "image/jpg")
        || ($_FILES["feature"]["type"] == "image/png"))) {
            if ($_FILES["feature"]["error"] > 0)
                echo "<p style='color: red;'>错误：: " . $_FILES["feature"]["error"] . "<p style='color: red;'><br>";
            else
            {   
                $year = $_POST["year"];
                $month = $_POST["month"];
                $target_url = "hw-imgs/" . $year . "_" . $month . ".jpg";
                move_uploaded_file($_FILES["feature"]["tmp_name"], $target_url);
                echo "<p style='color: red;'>设置 $year 年 $month 月的特色图片成功。</p><br><br>";
                echo "<img src='$target_url?random=$magic_num' style='height: 170px; width: 250px;'>";
            }
        }
        else
            echo "文件类型错误。";
    }
?>