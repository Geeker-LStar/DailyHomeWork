<!--作业发布后台（查询）-->

<?php
    session_start();
?>
<?php
    // 检查是否登录，未登录则要求登录
    if (!isset($_SESSION['user']))
        header("Location: login.php");
?>

<?php
    require_once("config.php");
    require_once("functions.php");
?>

<?php
    // 连接数据库
    date_default_timezone_set("PRC");    // 时区
    $conn = new mysqli($servername, $username, $password, $dbname);
    if ($conn->connect_error)
        die("连接失败：" . $conn->connect_error);
?>

<!DOCTYPE html>
<html>
    <head>
        <title>查询 - 作业发布后台</title>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="hw-css/button_style1.css">
    </head>
    
    <body>
        <?php
            // 说明是后台发起的查询
            if (isset($_GET["time"]))
            {
                $time = $_GET["time"];
                $year = substr($time, 0, 4);
                $month = substr($time, 5, 2);
                $day = substr($time, 8, 2);
                $tablen = $year . "_" . $month;
                $sql = "SHOW TABLES LIKE '{$tablen}'";
                $result = $conn->query($sql);
                $exist = $result->num_rows;
                // 不存在则报错
                if ($exist == 0)
                    echo "<br>数据表 " . $tablen . " 不存在。<br>";
                $sql = "SELECT * FROM {$tablen} WHERE date={$day}";
                $result = $conn->query($sql);
                $hw_arr = $result->fetch_assoc();
                $date = $hw_arr["date"];
                $yw = $hw_arr["Chinese"];
                $sx = $hw_arr["Math"];
                $yy = $hw_arr["English"];
                $wl = $hw_arr["Physics"];
                $hx = $hw_arr["Chemistry"];
                $sw = $hw_arr["Biology"];
                $dl = $hw_arr["Geography"];
                $ls = $hw_arr["History"];
                $df = $hw_arr["Politics"];
                $qt = $hw_arr["More"];
                
                $yw = delete_br_break($yw);
                $sx = delete_br_break($sx);
                $yy = delete_br_break($yy);
                $wl = delete_br_break($wl);
                $hx = delete_br_break($hx);
                $sw = delete_br_break($sw);
                $dl = delete_br_break($dl);
                $ls = delete_br_break($ls);
                $df = delete_br_break($df);
                $qt = delete_br_break($qt);

                if ($yw == null && $sx == $null && $yy == null)
                    echo("<br>未查找到 " . $tablen . "_" . $day . " 的作业。");
                else {
        ?>
        <h2>以下是<?php echo $tablen;?>_<?php echo $day;?> 的作业</h2>
        
        <form action="execute.php" method="POST">
            <input type="hidden" name="type" value="modify">
            <input type="hidden" name="tablen" value=<?php echo $tablen;?>>
            <input type="hidden" name="date" value=<?php echo $date;?>>
            <label for="yw">语文：</label><br>
            <textarea id="yw" name="yw" style="height: 200px; width: 400px;" class="form-control"><?php echo $yw;?></textarea><br>
            <label for="sx">数学：</label><br>
            <textarea id="sx" name="sx" style="height: 200px; width: 400px;" class="form-control"><?php echo $sx;?></textarea><br>
            <label for="yy">英语：</label><br>
            <textarea id="yy" name="yy" style="height: 200px; width: 400px;" class="form-control"><?php echo $yy;?></textarea><br>
            <label for="wl">物理：</label><br>
            <textarea id="wl" name="wl" style="height: 200px; width: 400px;" class="form-control"><?php echo $wl;?></textarea><br>
            <label for="hx">化学：</label><br>
            <textarea id="hx" name="hx" style="height: 180px; width: 400px;" class="form-control"><?php echo $hx;?></textarea><br>
            <label for="sw">生物：</label><br>
            <textarea id="sw" name="sw" style="height: 200px; width: 400px;" class="form-control"><?php echo $sw;?></textarea><br>
            <label for="dl">地理：</label><br>
            <textarea id="dl" name="dl" style="height: 200px; width: 400px;" class="form-control"><?php echo $dl;?></textarea><br>
            <label for="ls">历史：</label><br>
            <textarea id="ls" name="ls" style="height: 200px; width: 400px;" class="form-control"><?php echo $ls;?></textarea><br>
            <label for="df">道法：</label><br>
            <textarea id="df" name="df" style="height: 200px; width: 400px;" class="form-control"><?php echo $df;?></textarea><br>
            <label for="qt">其他：</label><br>
            <textarea id="qt" name="qt" style="height: 200px; width: 400px;" class="form-control"><?php echo $qt;?></textarea><br>
            <input type="submit" name="modify" value="确认修改" class="btn" style="-webkit-appearance: none;">
        </form>
        <?php
                };
            };
        ?>
        
        <?php
            // 说明是用户（在公有页面）发起的查询
            if (isset($_GET["time_public"]))
            {
                $time = $_GET["time_public"];
                $year = substr($time, 0, 4);
                $month = substr($time, 5, 2);
                $day = substr($time, 8, 2);
                $tablen = $year . "_" . $month;
                $sql = "SELECT * FROM {$tablen} WHERE date={$day}";
                $result = $conn->query($sql);
                if ($result->num_rows == 0)
                    echo "<br>未查找到 " . $tablen . "_" . $day . " 的作业。";
                else
                {   
                    $hw_arr = $result->fetch_assoc(); 
                    echo "<br><h2>以下是" . $time . "的作业：</h2>";
                    foreach ($hw_arr as $key => $value)
                    {
                        if ($key != "id" && $key != "date" && $value != null && $value != "无")
                        {
                            echo "<h3>" . $translation[$key] . "</h3>";
                            echo "<div style='line-height: 2'>" . $value . "</div>";
                        }
                    }
                }
            }
        ?>
    </body>
</html>