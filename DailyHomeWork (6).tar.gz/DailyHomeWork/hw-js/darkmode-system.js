/* MUST BE REQUIRED AFTER ./DARKMODE.JS HAS BEEN REQUIRED IN AN HTML FILE. */

/* SITE AUTO REACT TO CHANGING OF SYSTEM THEME. */


function gotodark() {
   
        document.getElementById("html").style.filter = "invert(1) hue-rotate(180deg)";
        var imgs = document.getElementsByTagName("img");
        for (var j = 0; j < imgs.length; j++)
        {
            imgs[j].style.filter = "invert(0.85) hue-rotate(180deg)"; 
            imgs[j].style.boxShadow = "5px 5px 10px rgba(240, 240, 240, 0.5)";
        }
        document.getElementById("switch").src = "./hw-imgs/dark_pic.png";
    
}

function gotolight() {
    document.getElementById("html").style.filter = "invert(0) hue-rotate(0deg)";
        var imgs = document.getElementsByTagName("img");
        for (var i = 0; i < imgs.length; i++)
        {
            imgs[i].style.filter = "invert(0) hue-rotate(0deg)";
            imgs[i].style.boxShadow = "5px 5px 10px rgba(20, 20, 20, 0.2)";
        }
        document.getElementById("switch").src = "./hw-imgs/light_pic.png";
   
}


window.matchMedia('(prefers-color-scheme: dark)').addEventListener('change', event => {
if(event.matches) {
gotodark();
}else{
gotolight();
}
})